Adeel Minhas
Web Systems Development - Lab 9

This lab took a while to finish. I extensively used PHP and PDO. I used the form method in html to account for the different options in creating this database, and performing the other operations that were needed for said lab. :). Overall, I do not understand why one would use PHP and PDO and prepared statements instead of using phpmyadmin for this task. Unless this was used before or there are certain security measures for using PHP and PDO, I don't get it. I hope you like my interface in this lab, as it is very plain (but it gets the job done). I noticed there were no points for creativity, which I find kind of odd. Well then, have a nice day!
