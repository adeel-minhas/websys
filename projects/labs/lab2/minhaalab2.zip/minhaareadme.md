Adeel Minhas
Web Systems Development - Lab 2

Part 1:
The reasoning for my markup was to just keep it simple. I thought using unordered lists for each song would be the best approach. It is plain and simple. (For the screenshot, I couldn't fit the whole thing). Also, I could not find the album information for the song "Stay With Me" on allmusic.com, so I used a different link.

Part 2:
My markup is pretty straightforward. I have tracks nested under my favorite songs. Under each track, I have information about the track, which includes the song name, artist, album, cover image, release, and genres. So it makes sense.

Part 3:
The markup I chose makes sense to me. First, in the body of my html file, I used a "Table" div and within that div, I divs for the header of my table. I also had "Row" divs. Within this "Row" div, I used separate classes for each attribute of the song, which included song name, artist, album, cover, release, and genres. This made it easy for me to modify the characteristics of these classes within my css when I had to.

So the organization of my html file was basically:

Table
  Row
    Attributes of Songs
End of Table
"End of list" under Table

Part 4:
*I couldn't fit my screenshot on one page*.
The xml is pretty much the same as in part 2, except I added links for artists and albums
