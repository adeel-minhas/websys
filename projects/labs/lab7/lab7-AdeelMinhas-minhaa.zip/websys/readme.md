Adeel Minhas
Web Systems Development - Quiz 1 Continuation (Lab 7)

This is my lab 7 website, which is essentially a continuation of my quiz website that I created. I utilized bootstrap heavily, adding a responsive menu as well as a slider on the main page that gives sort of a preview of what my labs and homeworks that I made so far. I didn't want to do anything crazy with this website and went for a simple and clean look.
