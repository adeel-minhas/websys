# what-the-hex

By Andrew Aquino, Vince Cerati, Barry Chau, Adeel Minhas, and Parker Slote.

## References

http://stackoverflow.com/questions/57803/how-to-convert-decimal-to-hex-in-javascript/57805#57805
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/abs
http://stackoverflow.com/a/15762794/6432160