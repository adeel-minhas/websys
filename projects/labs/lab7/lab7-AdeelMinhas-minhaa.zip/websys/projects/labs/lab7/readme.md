Adeel Minhas
Web Systems Development - Lab 7

Part 1
- Made my git repo, can be found here: https://github.com/adeelthegamer/websys

Part 2
- I drastically changed how my site looks with Bootstrap (mostly using this), and some jQuery UI. I have three main pages: a landing page, an about me page, and an assignments page.
- Concerning using JQuery UI, I added two effects on my about me page-> that is, I made my photo draggable and added an effect to the text under my photo with a click of a button.
Part 3
- I will make frequent changes to this website as I go. I also added a readme to the root of the repository.
