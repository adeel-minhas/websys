Adeel Minhas
Web Systems Development Lab 4

I wasn't sure how to add the heading of the table without messing with the cd page, so I left it out for now. I had small syntax errors in my ajax, which took me hours to debug. Also, I had to clear my cache since the ajax call was reading in an old json file (I didn't realize that till hours after). I added in a hover effect for the image and made a background color of yellowish cause I thought it looked cool. Enjoy!
