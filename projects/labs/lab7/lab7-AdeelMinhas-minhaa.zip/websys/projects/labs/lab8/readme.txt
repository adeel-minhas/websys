Adeel Minhas
Web Systems Development - Lab 8

In this lab, I used phpmyadmin to create three tables: students, courses and grades. Using the phpmyadmin interface made it easy to insert items into each of these tables. What was tricky was having foreign keys for the grades table. I wasn't sure how to do that, but one of my group members showed me how to do it. It was cool to see that the sql queries that I used for questions number 7, 8, 9 and 10 worked out properly.

I was unsure about what to do for number 9, so I got the average grade for the second course that I listed.

All my code for part 1 (where I inserted the tables and what not, should be in websyslab8.sql)

I put my code for questions 7 - 10 in a commands.txt file.

Have a nice day :)