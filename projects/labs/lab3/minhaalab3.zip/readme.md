Adeel Minhas
Web Systems Development
Lab 3

I heavily commented my javascript file so that should suffice. I had a bit of trouble getting the second part of part 3 to work correctly.
At first I was using margins to modify the divs. But then I saw that padding works a lot better in this case. Overall this lab was kind of tough,
but not too hard I guess.
